package minidb.models;

public enum DataType {
    INT, STR;
}
